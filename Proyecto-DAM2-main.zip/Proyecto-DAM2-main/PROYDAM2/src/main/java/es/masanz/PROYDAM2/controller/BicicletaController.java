package es.masanz.PROYDAM2.controller;

import es.masanz.PROYDAM2.model.entity.Bicicleta;
import es.masanz.PROYDAM2.model.entity.Usuario;
import es.masanz.PROYDAM2.model.service.BicicletaService;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Controller
public class BicicletaController {

    @Autowired
    private BicicletaService bicicletaService;

    @GetMapping("/catalogo")
    public String mostrarCatalogo(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Double precioMax,
            @RequestParam(required = false) List<String> marca,
            @RequestParam(required = false, defaultValue = "false") boolean soloEnStock,
            Model model) {

        // Si no hay filtros, todos los productos se muestran
        if (marca != null) {
            model.addAttribute("marca", marca);
        } else {
            marca = new ArrayList<>(); // Evitar que 'marcas' sea null
        }

        if (tipo != null) {
            model.addAttribute("tipo", tipo);
        }

        if (precioMax != null) {
            model.addAttribute("precioMax", precioMax);
        } else {
            precioMax = 20000.0;
        }

        if (soloEnStock) {
            model.addAttribute("soloEnStock", soloEnStock);
        }

        List<Bicicleta> bicicletas = bicicletaService.filtrarProductos(tipo, precioMax, marca, soloEnStock);
        model.addAttribute("bicicletas", bicicletas);

        return "catalogo";
    }

    @GetMapping("/catalogo/{id}")
    public String verProducto(@PathVariable String id, Model model) throws ExecutionException, InterruptedException {
        Bicicleta bicicleta = bicicletaService.findById(id);
        model.addAttribute("bicicleta", bicicleta);
        return "vistaProducto";
    }

    @GetMapping("/")
    public String galeria(Model model) {
        model.addAttribute("bicicletas", bicicletaService.obtenerProductos());
        return "index";
    }

    @PostMapping("/catalogo/{id}/sumar")
    public String sumarStock(@PathVariable String id, HttpSession session) {
        try {
            bicicletaService.sumarStock(id, session);
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
        return "redirect:/catalogo/" + id;
    }

    @PostMapping("/catalogo/{id}/restar")
    public String restarStock(@PathVariable String id, HttpSession session) {
        try {
            bicicletaService.restarStock(id, session);
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
        return "redirect:/catalogo/" + id;
    }
}

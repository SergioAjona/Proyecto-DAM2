import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import es.masanz.PROYDAM2.model.entity.Usuario;
import es.masanz.PROYDAM2.model.service.UsuarioService;
import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class CarritoControllerAdvice {

    private UsuarioService usuarioService;

    @ModelAttribute
    public void agregarCarritoGlobal(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario != null) {
            Usuario usuarioConCarrito = usuarioService.obtenerUsuarioPorId(usuario.getId());
            if (usuarioConCarrito != null && usuarioConCarrito.getCarrito() != null) {
                model.addAttribute("cantidadCarrito", usuarioConCarrito.getCarrito().size());
            } else {
                model.addAttribute("cantidadCarrito", 0);
            }
        } else {
            model.addAttribute("cantidadCarrito", 0);
        }
    }
}
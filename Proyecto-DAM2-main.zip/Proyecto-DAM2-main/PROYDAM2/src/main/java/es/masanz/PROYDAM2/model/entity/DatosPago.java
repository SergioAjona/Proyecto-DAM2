package es.masanz.PROYDAM2.model.entity;

public class DatosPago {
    private String id;
    private String nombre;
    private String email;
    private String direccion;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDireccion() {
        return direccion;
    }

}
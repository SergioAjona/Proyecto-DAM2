package es.masanz.PROYDAM2.model.service;

import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import es.masanz.PROYDAM2.model.entity.Bicicleta;
import es.masanz.PROYDAM2.model.entity.Usuario;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BicicletaService {

    private FirebaseService fb = new FirebaseService();

    public List<Bicicleta> filtrarProductos(String tipo, Double precioMax, List<String> marca, boolean soloEnStock) {
        CollectionReference productosRef = fb.getFirestore().collection("bicicletas");
        Query query = productosRef;

        if (tipo != null && !tipo.isEmpty()) {
            query = query.whereEqualTo("tipo", tipo);
        }
        if (precioMax != null && precioMax > 0) {
            query = query.whereLessThanOrEqualTo("precio", precioMax);
        }
        if (marca != null && !marca.isEmpty()) {
            query = query.whereIn("marca", marca);
        }
        if (soloEnStock) {
            query = query.whereGreaterThan("stock", 0);
        }

        List<Bicicleta> bicicletas = new ArrayList<>();
        try {
            QuerySnapshot snapshot = query.get().get();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                Bicicleta bicicleta = doc.toObject(Bicicleta.class);
                bicicleta.setId(doc.getId());
                bicicletas.add(bicicleta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bicicletas;
    }

    public List<Bicicleta> obtenerProductos() {
        List<Bicicleta> bicicletas = new ArrayList<>();

        try {
            QuerySnapshot querySnapshot = fb.getFirestore().collection("bicicletas").get().get();

            for (QueryDocumentSnapshot document : querySnapshot) {
                Bicicleta bicicleta = document.toObject(Bicicleta.class);
                bicicleta.setId(document.getId());
                bicicletas.add(bicicleta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bicicletas;
    }

    public Bicicleta findById(String id) {
        try {
            Firestore db = FirestoreClient.getFirestore();
            DocumentSnapshot document = db.collection("bicicletas").document(id).get().get();

            if (document.exists()) {
                Bicicleta bicicleta = document.toObject(Bicicleta.class);
                if (bicicleta != null) {
                    bicicleta.setId(document.getId());
                }
                return bicicleta;
            } else {
                throw new RuntimeException("Producto no encontrado con ID: " + id);
            }

        } catch (Exception e) {
            throw new RuntimeException("Error al obtener el producto: " + e.getMessage(), e);
        }
    }

    public void sumarStock(String id, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"admin".equals(usuario.getRol())) {
            throw new RuntimeException("Usuario sin privilegios");
        } else {
            Bicicleta bicicleta = findById(id);
            int nuevoStock = bicicleta.getStock() + 1;

            DocumentReference docRef = fb.getFirestore().collection("bicicletas").document(id);
            docRef.update("stock", nuevoStock);
        }
    }

    public void restarStock(String id, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"admin".equals(usuario.getRol())) {
            throw new RuntimeException("Usuario sin privilegios");
        } else {
            Bicicleta bicicleta = findById(id);
            if (bicicleta.getStock() > 0) {
                int nuevoStock = bicicleta.getStock() - 1;

                DocumentReference docRef = fb.getFirestore().collection("bicicletas").document(id);
                docRef.update("stock", nuevoStock);
            } else {
                throw new RuntimeException("Stock no disponible para restar");
            }
        }
    }
    
}
package es.masanz.PROYDAM2.model.service;

import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.lowagie.text.Document;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import es.masanz.PROYDAM2.model.entity.Bicicleta;
import es.masanz.PROYDAM2.model.entity.DatosPago;
import es.masanz.PROYDAM2.model.entity.Usuario;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class UsuarioService {

    @Autowired
    private FirebaseService fb;

    private BicicletaService bicicletaService;

    public String registrarUsuario(String token, Usuario datosUsuario) throws Exception {
        FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(token);
        String id = decodedToken.getUid();

        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID del usuario es inválido.");
        }

        Firestore db = fb.getFirestore();
        DocumentReference userRef = db.collection("usuarios").document(id);

        if (userRef.get().get().exists()) {
            throw new IllegalStateException("Usuario ya registrado");
        }

        Map<String, Object> userData = new HashMap<>();
        userData.put("id", id);
        userData.put("email", decodedToken.getEmail());
        userData.put("nombre", datosUsuario.getNombre());
        userData.put("apellido", datosUsuario.getApellido());
        userData.put("contrasena", datosUsuario.getContrasena());
        userData.put("telefono", datosUsuario.getTelefono());
        userData.put("dni", datosUsuario.getDni());
        userData.put("ciudad", datosUsuario.getCiudad());

        userRef.set(userData);

        return "Usuario registrado correctamente en Firestore";
    }

    public String loginUsuario(String token, HttpSession session) throws Exception {
        try {
            // Verificar el token
            FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(token);
            String id = decodedToken.getUid();

            // Buscar al usuario en Firestore (síncrono)
            DocumentReference userRef = fb.getFirestore().collection("usuarios").document(id);
            DocumentSnapshot documentSnapshot = userRef.get().get(); // .get() para bloquear hasta que obtenga el documento

            if (documentSnapshot.exists()) {
                // Usuario encontrado, obtén los detalles
                String contrasena = documentSnapshot.getString("contrasena");
                String email = documentSnapshot.getString("email");

                Usuario usuario = obtenerUsuarioPorId(id);
                session.setAttribute("usuario", usuario);

                // Puedes devolver una respuesta más detallada si es necesario
                return "Login exitoso. Usuario: (" + email + ")";
            } else {
                // El usuario no existe en Firestore
                return "El usuario no se encuentra en Firestore.";
            }
        } catch (Exception e) {
            // Manejo de excepciones en caso de error durante el proceso
            throw new Exception("Error en el login: " + e.getMessage());
        }
    }

    public void agregarProducto(String uid, String productoId) {
        try {
            Bicicleta bicicleta = bicicletaService.findById(productoId);

            DocumentReference docRef = fb.getFirestore().collection("usuarios")
                                         .document(uid)
                                         .collection("carrito")
                                         .document(productoId);

            docRef.set(bicicleta);
        } catch (Exception e) {
            throw new RuntimeException("Error al agregar al carrito: " + e.getMessage(), e);
        }
    }

    public void eliminarDelCarrito(String uid, String productoId) {
        try {
            var docRef = fb.getFirestore().collection("usuarios").document(uid);
            var snapshot = docRef.get().get();

            if (!snapshot.exists()) {
                throw new RuntimeException("Usuario no encontrado");
            }

            Usuario usuario = snapshot.toObject(Usuario.class);
            if (usuario == null || usuario.getCarrito() == null) return;

            List<Bicicleta> carritoActualizado = usuario.getCarrito().stream()
                    .filter(b -> !b.getId().equals(productoId))
                    .collect(Collectors.toList());

            docRef.update("carrito", carritoActualizado);
        } catch (Exception e) {
            throw new RuntimeException("Error al eliminar del carrito: " + e.getMessage(), e);
        }
    }

    public void vaciarCarrito(String id) {
        fb.getFirestore().collection("usuarios").document(id).update("carrito", new ArrayList<>());
    }

    public Usuario obtenerUsuarioPorId(String id) {
        try {
            DocumentSnapshot doc = fb.getFirestore().collection("usuarios").document(id).get().get();
            if (doc.exists()) {
                Usuario usuario = doc.toObject(Usuario.class);
                if (usuario != null) usuario.setId(doc.getId());
                return usuario;
            } else {
                throw new RuntimeException("Usuario no encontrado");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error al obtener usuario: " + e.getMessage(), e);
        }
    }

    public void generarFacturaPDF(Usuario usuario, List<Bicicleta> carrito, DatosPago datosPago, OutputStream out) throws Exception {
        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();

        // Encabezado
        String logoPath = "src/main/resources/static/imgs/logo_grande_final.png";
        Image logo = Image.getInstance(logoPath);
        logo.scaleToFit(100, 100);
        logo.setAlignment(Image.ALIGN_CENTER);
        document.add(logo);
        document.add(new Paragraph("Factura de compra"));
        document.add(new Paragraph("Usuario: " + usuario.getNombre() + " " + usuario.getApellido()));
        document.add(new Paragraph("Dirección de envío: " + datosPago.getDireccion()));
        document.add(new Paragraph("Correo electrónico asociado: " + datosPago.getEmail()));
        document.add(new Paragraph(" "));

        // Tabla de productos
        PdfPTable table = new PdfPTable(2);
        table.addCell("Producto");
        table.addCell("Precio");

        double total = 0.0;

        for (Bicicleta bici : carrito) {
            table.addCell(bici.getMarca() + " " + bici.getModelo());
            table.addCell(String.format("%.2f €", bici.getPrecio()));

            total += bici.getPrecio();
        }

        document.add(table);

        document.add(new Paragraph(" "));
        document.add(new Paragraph("Total: " + String.format("%.2f €", total)));

        document.close();
    }
}

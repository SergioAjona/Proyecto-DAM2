package es.masanz.PROYDAM2.controller;

import es.masanz.PROYDAM2.model.entity.Bicicleta;
import es.masanz.PROYDAM2.model.entity.Usuario;
import es.masanz.PROYDAM2.model.service.UsuarioService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.OutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import es.masanz.PROYDAM2.model.entity.DatosPago;

@RestController
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    private String limpiarToken(String token) {
        return token.replace("Bearer ", "");
    }

    @PostMapping("/registro")
    public ResponseEntity<String> registrar(@RequestHeader("Authorization") String token,
                                            @RequestBody Usuario datosUsuario, HttpSession session) {
        try {
            // Llamar al servicio para registrar al usuario en Firestore
            String respuesta = usuarioService.registrarUsuario(limpiarToken(token), datosUsuario);

            Usuario usuario = usuarioService.obtenerUsuarioPorId(datosUsuario.getId());
            session.setAttribute("usuario", usuario);

            return ResponseEntity.ok(respuesta);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/login")
    public String login(@RequestHeader("Authorization") String token, HttpSession session) {
        try {
            return usuarioService.loginUsuario(limpiarToken(token), session);
        } catch (Exception e) {
            return "Error en el inicio de sesión: " + e.getMessage();
        }
    }

    @PostMapping("/carrito/agregar/{productoId}")
    public String agregarAlCarrito(@PathVariable String productoId, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }
    
        usuarioService.agregarProducto(usuario.getId(), productoId);
        session.setAttribute("usuario", usuario);
        return "redirect:/catalogo";
    }
    
    @PostMapping("/carrito/eliminar/{productoId}")
    public String eliminarDelCarrito(@PathVariable String productoId, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
    
        if (usuario == null) {
            return "redirect:/login";
        }
    
        usuarioService.eliminarDelCarrito(usuario.getId(), productoId);
        session.setAttribute("usuario", usuario);
        return "redirect:/carrito";
    }

    @GetMapping("/carrito")
    public String verCarrito(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null) {
            return "redirect:/login";
        }

        Usuario usuarioActualizado = usuarioService.obtenerUsuarioPorId(usuario.getId());
        model.addAttribute("items", usuarioActualizado.getCarrito());
        return "carrito";
    }

    @GetMapping("/pago")
    public String mostrarFormularioPago(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
    
        if (usuario == null) {
            return "redirect:/login";
        }

        Usuario usuarioConCarrito = usuarioService.obtenerUsuarioPorId(usuario.getId());
        double total = 0;
        for (Bicicleta bicicleta : usuarioConCarrito.getCarrito()) {
            total += bicicleta.getPrecio();
        }
    
        model.addAttribute("carrito", usuarioConCarrito.getCarrito());    
        model.addAttribute("usuario", usuarioConCarrito);    
        model.addAttribute("total", total);
        return "pago";
    }

    @PostMapping("/pago/confirmar")
    public String procesarPagoYGenerarPDF(
            @ModelAttribute DatosPago datosPago,
            HttpSession session,
            HttpServletResponse response) {

        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        Usuario usuarioCompleto = usuarioService.obtenerUsuarioPorId(usuario.getId());
        List<Bicicleta> carrito = usuarioCompleto.getCarrito();

        usuarioService.vaciarCarrito(usuario.getId());
        session.setAttribute("usuario", usuario);

        // Generar PDF y devolverlo
        try {
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=baick-factura.pdf");

            OutputStream out = response.getOutputStream();
            usuarioService.generarFacturaPDF(usuarioCompleto, carrito, datosPago, out);
            out.close();
        } catch (Exception e) {
            throw new RuntimeException("Error al generar factura PDF: " + e.getMessage(), e);
        }

        return "/";
    }

}